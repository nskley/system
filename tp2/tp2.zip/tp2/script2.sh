#! /bin/sh

rm -rf $1/*
rm -r $1
