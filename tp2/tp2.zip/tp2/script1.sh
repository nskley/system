#! /bin/sh
mkdir $1
cp ./$2 $1
